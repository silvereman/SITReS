package com.Sonabel.SITReS.servicedemandes;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ServiceDemandesApplication {

	public static void main(String[] args) {
		SpringApplication.run(ServiceDemandesApplication.class, args);
	}

}

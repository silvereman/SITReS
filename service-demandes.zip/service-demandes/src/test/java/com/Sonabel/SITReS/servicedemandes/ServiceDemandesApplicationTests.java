package com.Sonabel.SITReS.servicedemandes;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ServiceDemandesApplicationTests {

	@Test
	void contextLoads() {
	}

}

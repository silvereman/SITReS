package com.sonabel.SITReS.servicefacture;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ServiceFactureApplication {

	public static void main(String[] args) {
		SpringApplication.run(ServiceFactureApplication.class, args);
	}

}

package com.sonabel.SITReS.servicefacture;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ServiceFactureApplicationTests {

	@Test
	void contextLoads() {
	}

}
